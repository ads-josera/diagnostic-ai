<?php
/**
 * Decide si un alumno tiene derecho al diagnóstico.
 *
 * @package Salesbumm\SLD
 */

declare( strict_types=1 );

namespace Salesbumm\SLD;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Responde a la única pregunta que Drupal le hace a WordPress.
 *
 * La respuesta se compone de dos condiciones independientes:
 *
 *  1. El alumno posee alguno de los cursos autorizadores.
 *  2. Su acceso al diagnóstico sigue dentro del periodo de vigencia.
 *
 * Que sean independientes es el punto central del diseño. El alumno conserva
 * el curso —sus vídeos, sus materiales— indefinidamente, pero el acceso al
 * diagnóstico caduca. Derivar la caducidad del curso sería imposible
 * precisamente porque el curso no caduca.
 *
 * Desde la 1.3.0 hay una segunda puerta: la suscripción. Quien tiene un curso
 * de suscripción entra a todos los agentes sin reloj propio, porque la
 * suscripción ya caduca sola: WooCommerce le retira el curso al cancelarse.
 * Cuando eso ocurre, vuelve a mandar lo de arriba sin cambio alguno.
 *
 * Toda la lógica de LearnDash queda encapsulada aquí. Si el cliente cambiara
 * de LMS, se reescribe esta clase y el módulo de Drupal no se entera.
 */
class CourseAccess {

	/**
	 * Ajustes del plugin.
	 *
	 * @var Settings
	 */
	private $settings;

	/**
	 * Reloj de vigencia.
	 *
	 * @var AccessClock
	 */
	private $clock;

	/**
	 * Constructor.
	 *
	 * @param Settings    $settings Ajustes.
	 * @param AccessClock $clock    Reloj de vigencia.
	 */
	public function __construct( Settings $settings, AccessClock $clock ) {
		$this->settings = $settings;
		$this->clock    = $clock;
	}

	/**
	 * Evalúa el derecho de acceso al diagnóstico de un usuario.
	 *
	 * @param int $user_id Identificador del usuario en WordPress.
	 *
	 * @return array{has_access: bool, started_at: ?int, expires_at: ?int, course_id: ?int, owned_courses: int[], reason: string}|null
	 *   La decisión, o NULL si no se ha podido determinar (por ejemplo, si
	 *   LearnDash no está disponible). NULL y "sin acceso" son cosas distintas
	 *   y Drupal las trata de forma distinta.
	 */
	public function evaluate( int $user_id ): ?array {
		if ( $user_id <= 0 || ! get_userdata( $user_id ) ) {
			return $this->deny( 'usuario inexistente' );
		}

		$courses = $this->settings->get_course_ids();

		if ( array() === $courses ) {
			return $this->deny( 'sin cursos autorizadores configurados' );
		}

		if ( ! function_exists( 'sfwd_lms_has_access' ) ) {
			// No se puede determinar. Se distingue de una denegación para que
			// Drupal pueda aplicar su política ante averías.
			return null;
		}

		$owned_courses = $this->find_owned_courses( $user_id, $courses );

		// El alumno tiene el curso: si nunca se le inició el reloj, se inicia
		// ahora. El origen de esa fecha es una decisión de negocio y por eso
		// es configurable.
		//
		// Se hace ANTES de mirar la suscripción y aunque la tenga: el periodo
		// del curso corre desde la compra, con o sin suscripción. Si no, al
		// cancelarla empezaría a contar de cero y le regalaría otro periodo.
		if ( array() !== $owned_courses ) {
			$this->clock->start_if_absent( $user_id, $this->resolve_start( $user_id, $owned_courses[0] ) );
		}

		$subscription = $this->find_subscription( $user_id );

		if ( null !== $subscription ) {
			$granted = $this->filter_existing( $courses );

			if ( array() !== $granted ) {
				return array(
					'has_access'    => true,
					'started_at'    => $this->enrolled_at( $user_id, $subscription ),
					// Sin fecha de fin: la suscripción es quien la marca. Al
					// cancelarse, WooCommerce retira el curso y este camino
					// deja de aplicarse.
					'expires_at'    => null,
					'course_id'     => $granted[0],
					// Todos los cursos que dan agente, como si los tuviera:
					// Drupal le concede así todos los agentes sin enterarse
					// de que existe la suscripción.
					'owned_courses' => $granted,
					'reason'        => 'acceso por suscripción',
				);
			}
		}

		if ( array() === $owned_courses ) {
			return $this->deny( 'no posee ningún curso autorizador' );
		}

		// `course_id` conserva el PRIMERO por compatibilidad: un Drupal que no
		// conozca todavía `owned_courses` sigue funcionando exactamente igual.
		$owned = $owned_courses[0];

		if ( ! $this->clock->is_active( $user_id ) ) {
			return array(
				'has_access'    => false,
				'started_at'    => $this->clock->get_started_at( $user_id ),
				'expires_at'    => $this->clock->get_expires_at( $user_id ),
				'course_id'     => $owned,
				'owned_courses' => $owned_courses,
				'reason'        => 'periodo de acceso caducado',
			);
		}

		return array(
			'has_access'    => true,
			// Cuando EMPEZO el periodo, no solo cuando acaba. Drupal lo
			// necesita para poder limitar el diagnostico a uno por periodo:
			// sin este dato no hay forma de saber que sesiones pertenecen al
			// periodo vigente y cuales son de una compra anterior.
			'started_at'    => $this->clock->get_started_at( $user_id ),
			'expires_at'    => $this->clock->get_expires_at( $user_id ),
			'course_id'     => $owned,
			// TODOS los cursos que posee, no solo el primero. Es lo que
			// permite a Drupal saber a que agentes tiene derecho el alumno:
			// alli cada agente declara el curso que lo concede.
			'owned_courses' => $owned_courses,
			'reason'        => 'acceso vigente',
		);
	}

	/**
	 * Reinicia el periodo de acceso de un usuario.
	 *
	 * Es lo que ocurre cuando el alumno vuelve a comprar: recupera el periodo
	 * completo desde ese momento.
	 *
	 * @param int    $user_id Usuario.
	 * @param string $reason  Motivo, para soporte.
	 */
	public function reactivate( int $user_id, string $reason ): void {
		$this->clock->start( $user_id, $reason );
	}

	/**
	 * Devuelve TODOS los cursos autorizadores que posea el alumno.
	 *
	 * Antes devolvía solo el primero y cortaba el bucle. Dejó de valer cuando
	 * el producto pasó a tener varios agentes: en Drupal cada agente declara
	 * qué curso lo concede, así que saber solo uno de los cursos del alumno
	 * equivalía a ocultarle los demás agentes que ha comprado.
	 *
	 * Se conserva el orden en que están configurados: Drupal usa el primero
	 * como `course_id` para no romper el contrato anterior.
	 *
	 * @param int   $user_id Usuario.
	 * @param int[] $courses Cursos configurados.
	 *
	 * @return int[] Cursos que posee, en el orden configurado.
	 */
	private function find_owned_courses( int $user_id, array $courses ): array {
		$owned = array();

		foreach ( $this->filter_existing( $courses ) as $course_id ) {
			// sfwd_lms_has_access() es la vía canónica de LearnDash y ya
			// contempla inscripción directa, compra, grupo y acceso abierto.
			if ( sfwd_lms_has_access( $course_id, $user_id ) ) {
				$owned[] = $course_id;
			}
		}

		return $owned;
	}

	/**
	 * El curso de suscripción que tiene el alumno, si tiene alguno.
	 *
	 * Tener el curso ES tener la suscripción al corriente: la integración de
	 * LearnDash con WooCommerce lo concede al pagar y lo retira al cancelarse
	 * o dejar de pagarse. Por eso aquí no se consulta WooCommerce.
	 *
	 * @param int $user_id Usuario.
	 */
	private function find_subscription( int $user_id ): ?int {
		$subscriptions = $this->filter_existing( $this->settings->get_subscription_course_ids() );

		foreach ( $subscriptions as $course_id ) {
			if ( ! self::is_free_for_all( $course_id ) && sfwd_lms_has_access( $course_id, $user_id ) ) {
				return $course_id;
			}
		}

		return null;
	}

	/**
	 * Indica si un curso lo puede tener cualquiera sin pagar.
	 *
	 * En LearnDash, un curso Abierto da acceso a todo usuario con sesión y uno
	 * Gratis a quien pulse inscribirse. Como curso de suscripción regalaría
	 * los dos agentes, así que no se acepta. Solo se aplica a la suscripción:
	 * los cursos que dan acceso siguen como estaban.
	 *
	 * @param int $course_id Curso.
	 */
	public static function is_free_for_all( int $course_id ): bool {
		if ( ! function_exists( 'learndash_get_setting' ) ) {
			return false;
		}

		$type = (string) learndash_get_setting( $course_id, 'course_price_type' );

		return in_array( $type, array( 'open', 'free' ), true );
	}

	/**
	 * Los cursos de la lista que están publicados, en el mismo orden.
	 *
	 * @param int[] $courses Cursos configurados.
	 *
	 * @return int[]
	 */
	private function filter_existing( array $courses ): array {
		$existing = array();

		foreach ( $courses as $course_id ) {
			if ( $this->course_exists( (int) $course_id ) ) {
				$existing[] = (int) $course_id;
			}
		}

		return $existing;
	}

	/**
	 * Fecha de alta del alumno en un curso, según LearnDash.
	 *
	 * @param int $user_id   Usuario.
	 * @param int $course_id Curso.
	 *
	 * @return int|null Marca de tiempo, o NULL si LearnDash no la expone.
	 */
	private function enrolled_at( int $user_id, int $course_id ): ?int {
		if ( ! function_exists( 'ld_course_access_from' ) ) {
			return null;
		}

		$from = ld_course_access_from( $course_id, $user_id );

		return is_numeric( $from ) && (int) $from > 0 ? (int) $from : null;
	}

	/**
	 * Decide desde cuándo cuenta el periodo de acceso de un alumno nuevo.
	 *
	 * Es una decisión de negocio, no técnica, y por eso se configura:
	 *
	 *  - Desde el alta en el curso: quien compró hace más de un año queda
	 *    caducado de inmediato. Es lo que dice el requisito al pie de la letra.
	 *  - Desde ahora: todos los alumnos existentes reciben el periodo completo
	 *    a partir del día en que se active la caducidad.
	 *
	 * Si se pide la fecha de alta y LearnDash no la expone, se cae a "ahora"
	 * en lugar de fallar: es preferible conceder de más a bloquear a un alumno
	 * por un dato que no hemos podido leer.
	 *
	 * @param int $user_id   Usuario.
	 * @param int $course_id Curso que le da acceso.
	 */
	private function resolve_start( int $user_id, int $course_id ): int {
		if ( 'enrollment' !== $this->settings->get_access_start_origin() ) {
			return time();
		}

		return $this->enrolled_at( $user_id, $course_id ) ?? time();
	}

	/**
	 * Comprueba que el identificador corresponda a un curso publicado.
	 *
	 * @param int $course_id Identificador del curso.
	 */
	private function course_exists( int $course_id ): bool {
		if ( $course_id <= 0 ) {
			return false;
		}

		$post = get_post( $course_id );

		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return false;
		}

		$course_post_type = function_exists( 'learndash_get_post_type_slug' )
			? learndash_get_post_type_slug( 'course' )
			: 'sfwd-courses';

		return $post->post_type === $course_post_type;
	}

	/**
	 * Construye una denegación.
	 *
	 * @param string $reason Motivo interno.
	 *
	 * @return array{has_access: bool, expires_at: ?int, course_id: ?int, reason: string}
	 */
	private function deny( string $reason ): array {
		return array(
			'has_access'    => false,
			'started_at'    => null,
			'expires_at'    => null,
			'course_id'     => null,
			'owned_courses' => array(),
			'reason'        => $reason,
		);
	}
}
